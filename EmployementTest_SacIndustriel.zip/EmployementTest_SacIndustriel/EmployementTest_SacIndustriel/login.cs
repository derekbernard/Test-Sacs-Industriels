﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployementTest_SacIndustriel
{
	public partial class login : Form
	{
		private MD5 md5Inst;
		public login()
		{
			InitializeComponent();
			button1.Enabled = false;
			md5Inst = MD5.Create();
		}


        private void button1_Click(object sender, EventArgs e)
        {
			SqlConnection connexion = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\tempDataBase\Users_SacsIndustriels.mdf;Integrated Security=True;Connect Timeout=30");
			SqlDataAdapter sqa = new SqlDataAdapter("Select * From [Table] Where username = '" + GetMd5Hash(usernameTextBox.Text) + "' And password = '" + GetMd5Hash(passwordTextBox.Text) + "'", connexion);
			DataTable dt = new DataTable();
			sqa.Fill(dt);

			if (dt.Rows.Count > 0)
			{
				this.Hide();
				dashboard entry = new dashboard();
				entry.Show();
			}
            else
            {
				MessageBox.Show("Le nom d'utilisateur ou le mot de passe est incorrect");
				passwordTextBox.Clear();
            }
		}

        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {
			button1.Enabled = usernameTextBox.TextLength > 0 && passwordTextBox.TextLength > 0;
		}

        private void passwordTextBox_TextChanged(object sender, EventArgs e)
        {
			button1.Enabled = usernameTextBox.TextLength > 0 && passwordTextBox.TextLength > 0;
		}

        private string GetMd5Hash(string textInput)
        {

            byte[] data = md5Inst.ComputeHash(Encoding.UTF8.GetBytes(textInput));

            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            return sBuilder.ToString();
        }
    }
}
